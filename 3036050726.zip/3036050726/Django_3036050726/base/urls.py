from django.urls import path
from .views import TableList, TableDetail,TableCreate, TableUpdate, DeleteView, UserLoginview, RegisterPage, CustomPasswordChangeView
from django.contrib.auth.views import LogoutView
from . import views


urlpatterns = [
    path('login/', UserLoginview.as_view(), name = 'login'),
    path('logout/', LogoutView.as_view(next_page='login'), name='logout'),
    path('register/', RegisterPage.as_view(), name='register'),
    path('password/', CustomPasswordChangeView.as_view(),name='password_change'),
    path('password_success/', views.password_success, name='password_success'),
    
    path('update_user/', views.update_user, name='update_user'),
    
    path('',TableList.as_view(), name = 'assets'),
    path('asset-view/<int:pk>/',TableDetail.as_view(), name = 'asset-view'),
    path('asset-create/',TableCreate.as_view(), name = 'asset-create'),
    path('asset-update/<int:pk>/',TableUpdate.as_view(), name = 'asset-update'),
    path('asset-delete/<int:pk>/',DeleteView.as_view(), name = 'asset-delete'),
]
