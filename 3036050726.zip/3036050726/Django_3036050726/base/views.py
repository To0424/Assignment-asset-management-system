from django.shortcuts import render, redirect
from django.views.generic.list import ListView
from django.views.generic.detail import DetailView 
from django.views.generic.edit import CreateView, UpdateView, DeleteView, FormView
from django.urls import reverse_lazy
from django.contrib.auth.models import User
from django.contrib.auth.views import LoginView

from .forms import UpdateUserForm
from django import forms
from django.contrib import messages


from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import login, views


from .models import Table

# Create your views here.

def update_user(request):
    if request.user.is_authenticated:
        current_user = User.objects.get(id=request.user.id)
        user_form = UpdateUserForm(request.POST or None, instance=current_user)
        if user_form.is_valid():
            user_form.save()
            login(request, current_user)
            messages.success(request, "User has been updated!!")
            return redirect('assets')
        return render(request,"base/update_user.html", {'user_form':user_form})
    else:
        messages.success(request, "You Must Be Logged In To Access That Page")
        return redirect('assets')

class CustomPasswordChangeView(views.PasswordChangeView):
    template_name = 'base/change-password.html'
    redirect_authenticated_user = True
    success_url = reverse_lazy('password_success')

def password_success(request):
    return render(request,'base/password_success.html')

class UserLoginview(LoginView):
    template_name = 'base/login.html'
    fields = '__all__'
    redirect_authenticated_user = True
    
    def get_success_url(self):
        return reverse_lazy('assets')

class RegisterPage(FormView):
    template_name = 'base/register.html'
    form_class = UserCreationForm
    redirect_authenticated_user = True
    success_url = reverse_lazy('assets')
    
    def form_valid(self,form):
        user = form.save()
        if user is not None:
            login(self.request, user)
        return super(RegisterPage, self).form_valid(form)
    
    #def get(self,*args,**kwargs):
     #   if self.request.user.is_authenticated:
    #        return redirect('assets')
    #    return super(RegisterPage,self).get(*args,**kwargs)

class TableList(LoginRequiredMixin, ListView):
    model = Table
    context_object_name = 'assets'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        user = self.request.user
        if user.is_superuser:
            context['assets'] = context['assets'].all()
        else:
            context['assets'] = context['assets'].filter(assigned_user=user)
        context['count'] = context['assets'].filter(assigned=False).count()
        
        search_input = self.request.GET.get('search-area') or ''
        if search_input:
            context['assets'] = context['assets'].filter(asset_name__icontains=search_input)
        context['search_input'] = search_input
        return context
    
    
    
class TableDetail(LoginRequiredMixin, DetailView):
    model = Table
    context_object_name = 'asset'
    template_name = 'base/table.html'

class TableCreate(LoginRequiredMixin, CreateView):
    model = Table
    fields = '__all__'
    success_url = reverse_lazy('assets')
    
    def form_invalid(self, form):
        form.instance.user = self.request.user
        return super(TableCreate, self).form_valid(form)
    

class TableUpdate(LoginRequiredMixin, UpdateView):
    model = Table
    fields = '__all__'
    success_url = reverse_lazy('assets')
    
class DeleteView(LoginRequiredMixin, DeleteView):
    model = Table
    context_object_name = 'asset'
    success_url = reverse_lazy('assets')
    