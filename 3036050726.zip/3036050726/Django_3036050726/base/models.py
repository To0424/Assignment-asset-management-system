from django.db import models
from django.contrib.auth.models import User
from datetime import date
# Create your models here.

class Table(models.Model):
    asset_name = models.CharField(max_length = 200)
    asset_desciption = models.TextField(null = True, blank = True)
    assigned = models.BooleanField(default = False)
    assigned_user = models.ForeignKey(User, on_delete=models.SET_NULL, null = True, blank = True)
    check_in_date_of_asset = models.DateField(default= date.today)
    check_out_date_of_asset = models.CharField(max_length = 200, default='NONE')
    barcode = models.CharField(max_length = 200, default='NONE')
    def __str__(self) -> str:
        return self.asset_name
    
    class Meta:
        ordering = ['assigned']
        
